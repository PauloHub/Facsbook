<!DOCTYPE HTML>
<!--
	Astral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>FacsBook</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div align="center">
			
		<img src="imagens\logobeta.png" width="250" height="190" >
		<!-- Main -->
		<div id="bloco1">
			<!-- Me -->
			<article id="contact" class="panel">
			<br><br>
			<form action="logar.php" method="post">
				<div>
					<div class="6u$ 12u$(mobile)">
						<input type="text" name="email" placeholder="Email" required />
					</div><br>
					<div class="6u 12u$(mobile)">
						<input type="password" name="senha" placeholder="Senha" required/>
					</div><br>
					<div class="12u$">
						<input type="submit" id="button_Padding" name="botao_login" value="Login" />
						<br>									
						<b><a id="opacity" href="cadastrar.php">Cadastre-se</a></b>
						<br>
						<br>
					</div>
				</div>
			</form>
			</article>
		</div>
		</div>
				<!-- Footer -->
					<div id="footer">
						<ul class="copyright">
							<li>&copy; Untitled.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>