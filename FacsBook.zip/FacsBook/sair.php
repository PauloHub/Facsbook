<?php 
include("restrito.php");
	session_destroy();
	header("location: login.php");
	
 ?>