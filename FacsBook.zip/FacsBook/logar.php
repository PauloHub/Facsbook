<?php
	error_reporting(1);
	
	if(isset($_POST["botao_login"])){

		$con = new mysqli("localhost", "root","","facsbook");
		if($con->connect_error == true){
			header("location: login.php");
			$msg_erro = $con->connect_error;
			echo "Erro de Conexão: ";
			exit;
		}else{
			$email = strtolower(addslashes($_POST["email"]));
			$senha = md5(addslashes($_POST["senha"]));
			//$senha = addslashes($_POST["senha"]);
			$sql_consulta = "SELECT * FROM usuarios";
			$return = $con->query($sql_consulta);
			$cont = 0;
			if($return == false){				
				echo "
					<script>
						alert('Erro ao consultar o banco de dados');
					</script>";
				header("location: login.php");
				echo $con->error;
			}else{
				while ($registro = $return->fetch_array()) {
					$email_consultado = strtolower(addslashes($registro["email"]));
					$senha_consultada = addslashes($registro["senha"]);
					if($email_consultado == $email && $senha_consultada == $senha){
						$cont ++;
					}
				}
				//Se cont for 0 significa que email e senha estão incorretas
				if($cont == 0){
					echo("<script type='text/javascript'>
						location.href='login.php';
						alert('Usuário ou senha incorretos');
						
						</script>");
		
					//echo "<a href='javascript:history.go(-1)'>Usuário e/ou Senha inválidos!</a>";
				}else{
					//setcookie("login", $email);	
					session_start();
					$_SESSION["email"] = $email;
					header("location: index.php");
				}
			}
		}
	}
?>