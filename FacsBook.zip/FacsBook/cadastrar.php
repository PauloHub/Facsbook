<?php 
	error_reporting(1);
	if($_POST != NULL){
		$con = new mysqli("localhost", "root","","facsbook");
		if($con->connect_error == true){
			$msg_erro = $con->connect_error;
			echo "Erro de Conexão: ";
			exit;
		}else{
			$nome = addslashes($_POST["nome"]);
			$email = strtolower(addslashes($_POST["email"]));
			$senha = md5(addslashes($_POST["senha"]));
			$sexo = ($_POST["sexo"]);
			if($sexo == ""){
				echo "
					<script>
						alert('Favor selecione o seu Sexo.');
					</script>";
			}else{
				$sql_consulta = "SELECT * FROM usuarios";
				$return = $con->query($sql_consulta);
				$cont = 0;
				if($return == false){
					echo "
						<script>
							alert('Erro ao consultar o banco de dados');
						</script>";
					echo $con->error;
				}else{
					while ($registro = $return->fetch_array()) {
						$email_consultado = strtolower(addslashes($registro["email"]));
						if($email_consultado == $email){
							$cont ++;
						}
					}
						//Se cont for 0 significa que email e senha estão incorretas
					if($cont != 0){
						echo "
						<script>
							alert('Já existe uma conta com este email.');
						</script>";
					}else{
						$sql_cadastrar = "INSERT INTO usuarios(email,senha,nome,sexo) VALUES('$email','$senha','$nome','$sexo')";
						$return2 = $con->query($sql_cadastrar);
						if($return == false){
							echo "
								<script>
									alert('Erro ao inserir no banco de dados');
								</script>";
							echo $con->error;
						}else{								
							echo "
								<script>
									alert('Cadastro realizado com sucesso!');
									location.href='login.php';
								</script>";	
						}
					}
				}
			}
		}	
	}
 ?>

<!DOCTYPE HTML>
<!--
	Astral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>FacsBook</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div align="center">
			<img src="imagens\logobeta.png" width="250" height="190">
			<!-- Main -->
			<div id="bloco1">
				<!-- Me -->
				<article id="contact" class="panel">
				<br>
				<form action="#" method="post">
				<div>
					<div class="6u$ 12u$(mobile)">
						<input type="text" name="nome" placeholder="Nome" required/>
					</div><br>
					<div class="6u$ 12u$(mobile)">
						<input type="text" name="email" placeholder="Email" required/>
					</div><br>
					<div class="6u 12u$(mobile)">
						<input type="password" name="senha" placeholder="Senha" required/>
					</div><br>
					<div class="6u$ 12u$(mobile)">						
						<select name="sexo" required>
							<option value="">Qual seu Sexo?</option>
							<option value="Feminino">Feminino</option>
							<option value="Masculino">Masculíno</option>
						</select> <br><br>
					</div>
					<div class="12u$">
						<input type="submit" id="button_Padding" nome="botao_cadastrar" value="Cadastrar-se"/>
						<br>									
						<b><a id="opacity" href="login.php">Login</a></b>
						<br>
					</div>
				</div>
				</form>
				</article>
			</div>
		</div>
		<!-- Footer -->
		<div id="footer">
			<ul class="copyright">
			<li>&copy; Untitled.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
			</ul>
		</div>
		<!-- Scripts -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/skel.min.js"></script>
		<script src="assets/js/skel-viewport.min.js"></script>
		<script src="assets/js/util.js"></script>
		<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
		<script src="assets/js/main.js"></script>
	</body>
</html>