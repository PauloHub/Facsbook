<?php 
	include("restrito.php");
	$nome = '';
	$id = 0;

	$con = new mysqli("localhost", "root","","facsbook");
		if($con->connect_error == true){
			$msg_erro = $con->connect_error;
			echo "Erro de Conexão: ";
			exit;
		}else{
			$sql_consulta = "SELECT * FROM usuarios";
			$return = $con->query($sql_consulta);
			if($return == false){
				echo "
					<script>
						alert('Erro ao consultar o banco de dados');
						</script>";
				echo $con->error;
			}else{
				while ($registro = $return->fetch_array()) {
					$email_consultado = strtolower(addslashes($registro["email"]));
					if($email_consultado == $_SESSION["email"]){
						$id = ($registro["id"]);
						$bio = ($registro["bio"]);
						$nome = addslashes($registro["nome"]);

					}
				}
			}
		}
	//Se clicar em publicar!
	if(isset($_POST["publish"])){
		if($_FILES["file"]["error"] > 0){
			$texto = $_POST["texto"];
			$hoje = date("Y-m-d");

			if($texto == ""){
				echo "
					<script>
						alert('Esta publicação parece estar em branco. Escreva algo ou anexe um link ou uma foto à publicação.');
					</script>";
			}else{
				$query = "INSERT INTO posts (data_criacao,id_usuario,texto) VALUES('$hoje',$id,'$texto')";
				$data = $con->query($query) or die();
				if($data){
					header("Location: ./");
				}else{
					echo "
					<script>
						alert('Alguma coisa não correu lá muito bem... Tente outr vez mais tarde');
					</script>";
				}
			}
		}else{
			$texto = $_POST["texto"];
			$date = date('Y-m-d H:i');
			$novo_nome = md5($date);
			$hoje = date("Y-m-d");
			move_uploaded_file($_FILES["file"]["tmp_name"], "imagens/".$novo_nome.".jpg");

			if($texto == ""){
				echo "
					<script>
						alert('Esta publicação parece estar em branco. Escreva algo ou anexe um link ou uma foto à publicação.');
					</script>";
			}else{
				$query = "INSERT INTO posts (data_criacao,id_usuario,texto,imagem) VALUES('$hoje',$id,'$texto', '$novo_nome.jpg')";
				$data = $con->query($query) or die();
				if($data){
					header("Location: ./");
				}else{
					echo "
					<script>
						alert('Alguma coisa não correu lá muito bem... Tente outr vez mais tarde');
					</script>";
				}
			}
		}
	}

	//Sugestões de usuários
	$array_sugestoes = array();

	$sql_sugestoes = "SELECT usuarios.id, usuarios.nome FROM usuarios WHERE usuarios.id != '$id' ORDER BY RAND() LIMIT 3";

	
		$return = $con->query($sql_sugestoes);
			if($return == false){
				echo "
					<script>
						alert('Erro ao consultar o banco de dados');
						</script>";
				echo $con->error;
			}else{
				while ($registro = $return->fetch_array()) {
					$array_sugestoes = $registro["nome"];

					//Verificar sugestões
					/*echo $registro["nome"];
					echo "<br>";*/
					
				}
			}
	


 ?>
		
<!DOCTYPE HTML>
<!--
	Astral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>FacsBook</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/home.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div align="right" style="margin-right: 10px;">
			<a style="text-decoration:none" href="sair.php" id="opacity" name="sair">Sair</a>
		</div>
		<!-- Wrapper-->
		<div id="wrapper">
			<!-- Nav -->
			<nav id="nav">					
				<a href="#home" class="icon fa-home active"><span>Home</span></a>
				<a href="#me" class="icon fa-user"><span>Perfil</span></a>
				<a href="#work" class="icon fa-folder"><span>Work</span></a>
				<a href="#contact" class="icon fa-envelope"><span>Contact</span></a>
				<a href="#" class="icon fa-twitter"><span>Twitter</span></a>
			</nav>

			<!-- Main -->
			<div id="main">
				<!-- Home -->
				<article id="home" class="panel">
					<header>
						<h2>Publicar</h2>
					</header>
					<div id="publicar">
						<form method="POST" accept-charset="utf-8" enctype="multipart/form-data">
							<textarea name="texto" placeholder="Escreva uma nova publicação"></textarea>
							<table border="0">
							<br>
							   <tr>
							     <td>
									<input type="submit" value="Publicar" name="publish" id="publicar">
							     </td>
							     <td align="right" width="30px">
									<label id="photo" for="file-input">
										<i class="fa fa-camera" aria-hidden="true" title="Inserir uma fotografia"></i>
									</label>
									<input type="file" id="file-input" name="imagem_perfil" hidden>
							     </td>
							   </tr>
							</table>
						</form>
						<hr align="center" width="100%" size="2">
						<br>
						<?php 
						//Carregar publicações
						$sql_pubs = "SELECT * FROM posts ORDER BY id DESC";
						$pubs = $con->query($sql_pubs);
						while ($pub = $pubs->fetch_array()){
							$id_pub = $pub["id"];
							$id_usuario = $pub["id_usuario"];
							$data_criacao = $pub["data_criacao"];
							$texto_pub = $pub["texto"];
							$imagem_pub = $pub["imagem"];
							//Identificar usuario dono do post
							$sql_consultar_usuario = "SELECT * FROM usuarios WHERE id='$id_usuario'";
							$retorno_usuario = $con->query($sql_consultar_usuario);
							$usuario_encontrado = $retorno_usuario->fetch_array();
							$nome_usuario_post = $usuario_encontrado["nome"];

							//Verificar se tem imagem na publicação
							if($imagem_pub == ""){
								echo "
					 				<div class='pub' id='$id'>
					 					<p><a href='#'><1nome_></1nome_>usuario_post</a></p>
					 					<span>$texto_pub</span>
					 					<br>
					 					Data: $data_criacao
									 </div>
									 <br>
								";
							}else{
								echo "
					 				<div class='pub' id='$id_pub'>
									 	<p><a href='#'>$nome_usuario_post</a></p>
									 	<span>$texto_pub</span>
									 	<br>
									 	Data: $data_criacao
									 	<img id='imagem_post' src='imagens/$imagem_pub'>
									 </div>
									 <br>
								";
							}
						}
					 ?>

					</div>
				</article>

						<!-- Me -->
							<article id="me" class="panel">
								<header>
									<h1>Olá <?php echo "$nome"; ?></h1>
									<p>Bem Vindo a FacsBook!</p>
								</header>
								<img class="jumplink pic" src="imagens/me.jpg" alt=""/>
								<form method="POST" accept-charset="utf-8" enctype="multipart/form-data">
									<span>
										<div align="right" style="position: relative; margin-right: 10px;">
											<label id="photo" for="file-input">
												<i class="fa fa-picture-o" aria-hidden="true" title="Alterar Imagem do Perfil"></i>
											</label>
											<input type="file" id="file-input" name="imagem_perfil" hidden>
										</div>
									</span>
								</form>								
							</article>

						<!-- Work -->
							<article id="work" class="panel">
								<header>
									<h2>Work</h2>
								</header>
								<p>
									Phasellus enim sapien, blandit ullamcorper elementum eu, condimentum eu elit.
									Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia
									luctus elit eget interdum.
								</p>
								<section>
									<div class="row">
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic01.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic02.jpg" alt=""></a>
										</div>
										<div class="4u$ 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic03.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic04.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic05.jpg" alt=""></a>
										</div>
										<div class="4u$ 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic06.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic07.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic08.jpg" alt=""></a>
										</div>
										<div class="4u$ 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic09.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic10.jpg" alt=""></a>
										</div>
										<div class="4u 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic11.jpg" alt=""></a>
										</div>
										<div class="4u$ 12u$(mobile)">
											<a href="#" class="image fit"><img src="imagens/pic12.jpg" alt=""></a>
										</div>
									</div>
								</section>
							</article>

						<!-- Contact -->
							<article id="contact" class="panel">
								<header>
									<h2>Contact Me</h2>
								</header>
								<form action="#" method="post">
									<div>
										<div class="row">
											<div class="6u 12u$(mobile)">
												<input type="text" name="name" placeholder="Name" />
											</div>
											<div class="6u$ 12u$(mobile)">
												<input type="text" name="email" placeholder="Email" />
											</div>
											<div class="12u$">
												<input type="text" name="subject" placeholder="Subject" />
											</div>
											<div class="12u$">
												<textarea name="message" placeholder="Message" rows="8"></textarea>
											</div>
											<div class="12u$">
												<input type="submit" value="Send Message" />
											</div>
										</div>
									</div>
								</form>
							</article>

					</div>

				<!-- Footer -->
					<div id="footer">
						<ul class="copyright">
							<li>&copy; Untitled.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script> 

	</body>
</html>